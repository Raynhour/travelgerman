$('document').ready(function(){

	$('.owl-carousel').owlCarousel({
	    nav:true,
	    navText: ["<img src='../img/prev.png'>","<img src='../img/next.png'>"],
	    center:false,
	    loop:true,
		smartSpeed: 1000,
		fluidSpeed: true,
	    items : 3
	});
	
});